import java.util.ArrayList;

public class User {
	private String name;
	private String email;
	ArrayList<User> Friends = new ArrayList<User>();
	ArrayList<Group> groups= new ArrayList<Group>();

	//κατασκευαστή της κλάσης User
	public User(String text1, String text2){
		if(isValid(text2)) {
			name=text1;
		    email=text2;}
       else {   System.out.println("CONSOLE:");
		    	System.out.println("User " + text1 + " has not been created.Email format is not acceptable.");
       }
	}
	//Μέθοδος επικύρωσης email
	public boolean isValid(String email) {
		String end="uom.edu.gr";
		if (!email.endsWith(end))
			return false;
		if (!email.startsWith("iis") && !email.startsWith("ics") && !email.startsWith("dai"))
			return false;
		int s= email.indexOf('@');
		if (s==-1)
		    return false;
		String digits = email.substring(3,s);
		int len = digits.length();
		if (len != 3 && len != 4 && len != 5)
		    return false;
		return true;}
	
//Μέθοδος που ελέγχει αν ειναι φίλος
	public boolean friends(User other) {
	    if (other == null) return false;
	    for (User u : Friends) {
	        if (u.equals(other)) {
	            return true;}}

	    return false; 
	}

	 //Προσθήκη φίλων   	  
    public void addfriend(User friend) {
        if (friend == null || friend == this) {
            return;}
        boolean already = false;
        for (User u : Friends) {
            if (u.equals(friend)) {
                already = true;
                break;}}
        if (!already) {
             Friends.add(friend);
            System.out.println(this.name + " and " + friend.name + " are now friends!");
            boolean already2 = false;
            for (User u2 : friend.Friends) {
                if (u2.equals(this)) {
                    already2 = true;
                    break;}}
            if (!already2) {
                friend.Friends.add(this); }}}
    //Δημιουργία λίστας κοινών φίλων
    public void commonFriends(User other) {
    	ArrayList<User> com_friends= new ArrayList<User>();
   
        for (User u1 : this.Friends) {
            for (User u2 : other.Friends) {
                if (u1.equals(u2)) {
                    com_friends.add(u1);}} }
         int i=1;
        for (User u : com_friends) {
            System.out.println(i + " : " + u.name);
            i++;}}
       //Εκτύπωση δεδομένων
    public void printData() {
    	int i=1;
    	for (User u1 : Friends) {
    		System.out.println(i + " : " + u1.name);
    	    i++;}
    }
     // προσθήκη γκρούπ
    public void addgroup(Group g) {
        boolean exists = false;
        for (Group group : groups) {
            if (group .equals(g)) { 
                exists = true;
                break;}}
        if (!exists) {
            groups.add(g);} }
     //Εκτύπωση γκρούπ
    public void printGroups() {
        int i = 1;
        for (Group g : groups) {
            System.out.println(i + " : " + g.getName());
            i++;
        }
    }
	public String getName() {
		return name;
	}
	//Μέθοδος σε περίπτωση ιού
	public void Virus() {
	    ArrayList<User> virus = new ArrayList<User>();
	    for (User friend : Friends) {
	        boolean exists = false;
	        for (User u : virus) {
	            if (u.equals(friend)) {
	                exists = true;
	                break;}}
	        if (!exists) {
	            virus.add(friend);}}
	    for (User friend : Friends) {
	        for (User friendsFriend : friend.Friends) {
	            if (friendsFriend != this) {
	                boolean exists = false;
	                for (User u : virus) {
	                    if (u.equals(friendsFriend)) {
	                        exists = true;
	                        break;}}

	                if (!exists) {
	                    virus.add(friendsFriend);}}}}
	    
	    for (User u : virus) {
	        System.out.println(u.getName());
	    }
	}

	}


	
		
    
   


 