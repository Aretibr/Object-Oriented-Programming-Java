import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		User u1 = new User("Makis","iis2598@uom.edu.gr");
		User u2 = new User("Petros","ics2524@uom.edu.gr");
		User u3 = new User("Maria","iis2512@uom.edu.gr");
		User u4 = new User("Gianna","iis25133@uom.edu.gr");
		User u5 = new User("Nikos","dai1758@uom.edu.gr");
		User u6 = new User("Babis","ics25104@uom.edu.gr");
		User u7 = new User("Stella","dai1827@uom.edu.gr");
		User u8 = new User("Eleni","ics2586@gmail.com");
		
		System.out.println("CONSOLE:");
		//Προσθήκη χρηστών
		u1.addfriend(u2);
        u1.addfriend(u5);
        u5.addfriend(u6);
        u3.addfriend(u4);
        u3.addfriend(u2);
        u4.addfriend(u6);
        u5.addfriend(u3);
        u1.addfriend(u6);
        u5.addfriend(u2);
        u7.addfriend(u1);
        
        for (int i = 0; i < 38; i++) {
            System.out.print("*");}
        System.out.println();
        // Εκτύπωση κοινών φίλων Νίκου και Γίαννας
        System.out.println("Common friends of Nikos and Gianna");
        
        for (int i = 0; i < 38; i++) {
            System.out.print("*");}
        System.out.println();
        
        u5.commonFriends(u4);
        
        for (int i = 0; i < 38; i++) {
            System.out.print("-");
        }
        System.out.println();
        
        for (int i = 0; i < 38; i++) {
            System.out.print("*");}
        System.out.println();
        //Εκτύπωση κοινών φίλων Νίκου και Μάκη
        System.out.println("Common friends of Makis and Nikos");
        
        for (int i = 0; i < 38; i++) {
            System.out.print("*");}
        System.out.println();
        
        u1.commonFriends(u5);
        
        for (int i = 0; i < 38; i++) {
            System.out.print("-");
        }
        System.out.println();
        for (int i = 0; i < 24; i++) {
            System.out.print("*");}
        System.out.println();
        //Εκτύπωση φίλων του Μάκη
        System.out.println("Friends of Makis");
        for (int i = 0; i < 24; i++) {
            System.out.print("*");}
        System.out.println();
        
        u1.printData();
        
        for (int i = 0; i < 23; i++) {
            System.out.print("-");}
        System.out.println();
        
        for (int i = 0; i < 24; i++) {
            System.out.print("*");}
        System.out.println();
        //Εκτύπωση φίλων Μαρίας
        System.out.println("Friends of Maria");
        for (int i = 0; i < 24; i++) {
            System.out.print("*");}
        System.out.println();
        
        u3.printData();
        
        for (int i = 0; i < 23; i++) {
            System.out.print("-");}
        System.out.println();
        
        Group g1 = new Group("WebGurus","A group for web passionates");
        ClosedGroup g2 = new ClosedGroup("ExamSolutions","Solutions to common exam questions");
        //Εισαγωγή σε γκρουπ
        g1.becomeMember(u4);
        g1.becomeMember(u3);
        g1.becomeMember(u2);
        
        g2.becomeMember(u4);
        g2.becomeMember(u5);
        g2.becomeMember(u6);
        g2.becomeMember(u5);

        
        for (int i = 0; i < 38; i++) {
            System.out.print("*");}
        System.out.println();
        //Γκρουπ της Γίαννας
        System.out.println("Groups that Gianna has been enrolled in");
        for (int i = 0; i < 38; i++) {
            System.out.print("*");}
        System.out.println();
        
        u4.printGroups();
        
        for (int i = 0; i < 38; i++) {
            System.out.print("-");}
        System.out.println();
       
        for (int i = 0; i < 31; i++) {
            System.out.print("*");}
        System.out.println();
        //Μέλη του γκρούπ WebGurus
        System.out.println("Members of group WebGurus");
        
        for (int i = 0; i < 31; i++) {
            System.out.print("*");}
        System.out.println();
        
        g1.printInfo();
        
        for (int i = 0; i < 29; i++) {
            System.out.print("-");}
        System.out.println();
        
        for (int i = 0; i < 31; i++) {
            System.out.print("*");}
        System.out.println();
        //Μέλη του γκρούπ ExamSolutions
        System.out.println("Memebers of group ExamSolutions");
        for (int i = 0; i < 31; i++) {
            System.out.print("*");}
        System.out.println();
        
        g2.printInfo();
        for (int i = 0; i < 29; i++) {
            System.out.print("-");}
        System.out.println();
        
        for (int i = 0; i < 31; i++) {
            System.out.print("*");}
        System.out.println();
        
        System.out.println("Gianna has been infected. The following users have to be tested");
        
        for (int i = 0; i < 31; i++) {
            System.out.print("*");}
        System.out.println();
        
        u4.Virus();
        
        for (int i = 0; i < 29; i++) {
            System.out.print("-");}
        System.out.println();
        
        ArrayList<User> users = new ArrayList<User>();
        users.add(u1);
        users.add(u2);
        users.add(u3);
        users.add(u4);
        users.add(u5);
        users.add(u6);
        users.add(u7);
        users.add(u8);
        new UserFrame(users); 
        
        
	}

}
