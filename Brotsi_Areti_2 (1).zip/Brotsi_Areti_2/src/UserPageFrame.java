import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class UserPageFrame extends JFrame {

    private JPanel panel = new JPanel();
    
    private JButton backButton = new JButton("Back to Login Screen");
    private JTextField postField = new JTextField(20);
    private JButton postButton = new JButton("Post");
    private JTextArea postsArea = new JTextArea(15, 20);
    private JTextArea suggestedArea = new JTextArea(5, 20);
    private User user;

    public UserPageFrame(User user) {
        this.user = user;
        postsArea.setEditable(false);
        suggestedArea.setEditable(false);
        suggestedArea.setOpaque(false);
        
        JTextField nameField = new JTextField(user.getName(), 5);
        nameField.setEditable(false);
        nameField.setBackground(java.awt.Color.WHITE);
        JTextField emailField = new JTextField(user.getEmail(), 15);
        emailField.setEditable(false);
        emailField.setBackground(java.awt.Color.WHITE);

        panel.add(nameField);
        panel.add(emailField);
        panel.add(backButton);
        panel.add(postField);
        panel.add(postButton);
        panel.add(new JLabel("Recent Posts by Friends"));
        panel.add(new JScrollPane(postsArea));
        panel.add(new JLabel("Suggested Friends"));
        JScrollPane suggestedSpace = new JScrollPane(suggestedArea);
        suggestedSpace.setBorder(null);
        panel.add(suggestedSpace);

        ButtonListener postlistener = new ButtonListener();
        postButton.addActionListener(postlistener);
        ButtonListener backlistener = new ButtonListener();
        backButton.addActionListener(backlistener);
        Posts();
       Suggested();
       
        this.setContentPane(panel);
        this.setSize(400, 600);
        this.setTitle("Σελίδα Χρήστη");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    private void Posts() {
        String text1 = " ";
        for (Post p : user.getAllPosts()) {
            text1 += p.toString() + "\n";
        }postsArea.setText(text1);}

    private void Suggested() {
        String text = " ";
        for (User u : user.suggestedFriends()) {
            text += u.getName() + "\n";
        } suggestedArea.setText(text);}

    class ButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            if (e.getSource() == postButton) {
                String text = postField.getText();
                if (!text.isEmpty()) {
                    user.addPost(text);
                    postField.setText("");
                    Posts();}}
            if (e.getSource() == backButton) {
                dispose();}}}
    }
