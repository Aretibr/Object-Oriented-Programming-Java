import java.text.SimpleDateFormat;
import java.util.Date;

public class Post {

	private Date timestamp;
	private String text;
	private User user;
	
	public Post( User username, String text1) {
		user=username;
		text= text1;
		timestamp= new Date();
		
	}

	public User getUser() {
		return user;
	}

	public Date getTimestamp() {
		return timestamp;
	}
	
	 public String toString() {
	        SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss μ.μ.");
	        return user.getName() + " ," + date.format(timestamp) + ", " + text;
	    }

}
