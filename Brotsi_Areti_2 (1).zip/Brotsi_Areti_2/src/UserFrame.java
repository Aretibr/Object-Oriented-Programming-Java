import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class UserFrame extends JFrame{
   private JPanel panel= new JPanel();
   private JTextField entername = new JTextField("Please enter your name...");
   private JButton Buttonpage = new JButton("Enter User Page");
   private JButton ButtonShow = new JButton("Show Potential Inflections");
   
   private ArrayList<User> users; 
   
   public UserFrame(ArrayList<User> users) {
	   this.users = users;
	   
	   panel.add(entername);
	   panel.add(Buttonpage);
	   panel.add(ButtonShow);
	   
	   this.setContentPane(panel);
	   
	   ButtonListener listener = new ButtonListener();
	   Buttonpage.addActionListener(listener);
	   ButtonShow.addActionListener(listener);
	   
	   this.setVisible(true);
		this.setSize(250, 250);
		this.setTitle("Είσοδος Χρήστη");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
   }
   
   class ButtonListener implements ActionListener {
	    @Override
	    public void actionPerformed(ActionEvent e) {
	        String name = entername.getText();
	        if (name == null ) {
	        	JOptionPane.showMessageDialog(UserFrame.this,"User " + name + " Not Found","Message",JOptionPane.INFORMATION_MESSAGE);
	            return;}
	        User userfound = null;
	        for (User u : users) {
	            if (name.equals(u.getName())) { 
	                userfound = u;
	                break;}}
	        if (e.getSource() == Buttonpage) {
	            if (userfound == null) {
	            	JOptionPane.showMessageDialog(UserFrame.this,"User " + name + " Not Found","Message",JOptionPane.INFORMATION_MESSAGE);
	            } else {
	                new UserPageFrame(userfound);}}
	        if (e.getSource() == ButtonShow) {
	            if (userfound == null) {
	            	JOptionPane.showMessageDialog(UserFrame.this,"User " + name + " Not Found","Message",JOptionPane.INFORMATION_MESSAGE); 
	            } else { 
	            	new VirusPage(userfound);}}}}

}



