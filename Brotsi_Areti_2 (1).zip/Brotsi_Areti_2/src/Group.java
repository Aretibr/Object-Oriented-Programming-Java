import java.util.ArrayList;

public class Group {
	
	protected String name;
	private String description;
	ArrayList<User> members = new ArrayList<User>();
	//κατσκευαστης κλάσης Group
	public Group(String text1,String text2) {
		name=text1;
		description=text2;	
	}
	//έλεγχος μέλλους
	public boolean isMember(User u) {
	    for (int i = 0; i < members.size(); i++) {
	        if (members.get(i).equals(u)) {
	            return true;}}
	    return false;
	}
	//προσθήκη μελών
	public void becomeMember(User u) {
		if(!isMember(u)) {
			members.add(u);
			u.addgroup(this);
			System.out.println(u.getName()+ " has been successfully enrolled in group " + name);
		}
	}
    //εκτύπωση μελών
   public void printInfo() {
	   int i = 1;
       for (User u : members) {
           System.out.println(i + " : " + u.getName());
           i++;
       }
	   
   }

   public String getName() {
	return name;
   }

   
	

}
