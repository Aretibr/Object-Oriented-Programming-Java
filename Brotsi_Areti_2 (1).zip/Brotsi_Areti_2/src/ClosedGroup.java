import java.util.ArrayList;

public class ClosedGroup extends Group {

	ArrayList<ClosedGroup> closed_group = new ArrayList<ClosedGroup>();
	//κατασκευαστής υποκλάσης ClosedGroup
	public ClosedGroup(String text1,String text2){
		super(text1,text2);}
	//προσθήκη μέλους
	public void becomeMember(User u) {
	    if (members.isEmpty()) {
	        super.becomeMember(u);
	        return;}

	    for (User member : members) {
	        if (member.friends(u)) {
	            super.becomeMember(u);
	            return;}}
	    System.out.println("FAILED: " + u.getName() + " cannot be enrolled in group " + getName());
	}
	public void printInfo() {
		super.printInfo();
	}
	
	
}
