import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VirusPage extends JFrame {

    private JPanel panel = new JPanel();
    private JTextArea virusArea = new JTextArea(15, 30);
    private JButton backButton = new JButton("Back to Login Screen");
    private User user;

    public VirusPage(User user) {
        this.user = user;
        virusArea.setEditable(false);
        virusArea.setOpaque(false);
        virusArea.setBorder(null);
        
        panel.add(new JLabel("******************************************************************************"));
        panel.add(new JLabel(user.getName() + " has been inflected. The following users have to be tested"));
        panel.add(new JLabel("******************************************************************************"));
        
        JScrollPane virusNames = new JScrollPane(virusArea);
        virusNames.setBorder(null);
        virusNames.setOpaque(false);
        panel.add(virusNames);
        panel.add(backButton);
        
        VirusList();
        
        ButtonListener listener= new ButtonListener();
        backButton.addActionListener(listener);

        
        this.setContentPane(panel);
        this.setSize(400, 400);
        this.setTitle("Πιθανή Μετάδοση Ιού");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    private void VirusList() {
        String text = "";
        for (User u : user.Virus()) {
            text += u.getName() + "\n"; }
        virusArea.setText(text);}

    
class ButtonListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        dispose();
    }
}}
